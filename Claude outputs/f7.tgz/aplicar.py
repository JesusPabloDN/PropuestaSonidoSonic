import os, re, sys, glob, shutil

BASE = sys.argv[1]
PAQ = sys.argv[2]           # carpeta con los archivos nuevos (java/, res/, snippets/)
DRY = len(sys.argv) > 3 and sys.argv[3] == 'dry'
MAIN = os.path.join(BASE, 'app/src/main')
RES = os.path.join(MAIN, 'res')
JAVA = os.path.join(MAIN, 'java/com/example/propuestasonidosonic')
log = []


def leer(p):
    with open(p, encoding='utf-8', newline='') as f:
        return f.read()


def escribir(p, t, t0=None):
    if t != t0:
        log.append(os.path.relpath(p, BASE))
        if not DRY:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, 'w', encoding='utf-8', newline='') as f:
                f.write(t)


def nl(t):
    return '\r\n' if '\r\n' in t else '\n'


def reemplazar(t, viejo, nuevo, n=1):
    assert t.count(viejo) == n, (viejo[:90], t.count(viejo))
    return t.replace(viejo, nuevo)


def insertar_antes_cierre(t, cierre, lineas):
    s = nl(t)
    i = t.rindex(cierre)
    return t[:i].rstrip() + s + s.join(lineas) + s + t[i:]


# ---------- 1. Archivos nuevos o reescritos ----------
nuevos_permitidos_existentes = {'java/com/example/propuestasonidosonic/ui/socio/DashboardFragment.java',
                                'res/layout/fragment_dashboard.xml'}
for raiz in ('java', 'res'):
    for origen in glob.glob(os.path.join(PAQ, raiz, '**', '*'), recursive=True):
        if os.path.isdir(origen):
            continue
        rel = os.path.relpath(origen, PAQ)
        destino = os.path.join(MAIN, rel)
        if os.path.exists(destino):
            assert rel.replace(os.sep, '/') in nuevos_permitidos_existentes, rel
        t = leer(origen)
        if '\r\n' not in t:
            t = t.replace('\n', '\r\n')
        escribir(destino, t, leer(destino) if os.path.exists(destino) else None)

# ---------- 2. DashboardUtils ----------
p = JAVA + '/domain/DashboardUtils.java'
t0 = leer(p)
assert 'eventosPorDiaSemana' not in t0
extra = leer(os.path.join(PAQ, 'snippets/DashboardUtils_extra.java')).replace('\r\n', '\n').replace('\n', nl(t0))
i = t0.rstrip().rindex('}')
escribir(p, t0[:i].rstrip() + nl(t0) + extra.rstrip() + nl(t0) + '}' + nl(t0), t0)

# ---------- 3. attrs ----------
p = RES + '/values/attrs.xml'
t0 = leer(p)
escribir(p, insertar_antes_cierre(t0, '</resources>', [
    '    <attr name="colorFondoPantalla" format="color" />',
    '    <attr name="colorTarjeta" format="color" />',
    '    <attr name="colorFilaAccion" format="color" />']), t0)

# ---------- 4. dimens ----------
p = RES + '/values/dimens.xml'
t0 = leer(p)
escribir(p, insertar_antes_cierre(t0, '</resources>', [
    '    <dimen name="card_corner_radius_grande">24dp</dimen>',
    '    <dimen name="fila_corner_radius">16dp</dimen>']), t0)

# ---------- 5. temas ----------
p = RES + '/values/themes.xml'
t0 = leer(p)
s = nl(t0)
t = reemplazar(t0, '<item name="materialCardViewStyle">@style/Widget.SonidoSonic.CardView.Outlined</item>',
               '<item name="materialCardViewStyle">@style/Widget.SonidoSonic.CardView.Tarjeta</item>')
ancla = '<item name="toolbarStyle">@style/Widget.SonidoSonic.Toolbar</item>'
ind = re.search(r'([ \t]*)' + re.escape(ancla), t).group(1)
t = reemplazar(t, ancla, s.join([
    '<item name="colorFondoPantalla">?attr/colorSurfaceContainer</item>',
    ind + '<item name="colorTarjeta">?attr/colorSurfaceContainerLowest</item>',
    ind + '<item name="colorFilaAccion">?attr/colorSurfaceContainer</item>',
    ind + '<item name="android:windowBackground">?attr/colorFondoPantalla</item>',
    '',
    ind + ancla,
    ind + '<item name="toolbarNavigationButtonStyle">@style/Widget.SonidoSonic.Toolbar.Navegacion</item>']))
escribir(p, t, t0)

p = RES + '/values-night/themes.xml'
t0 = leer(p)
s = nl(t0)
ancla = '<item name="android:windowLightStatusBar">false</item>'
ind = re.search(r'([ \t]*)' + re.escape(ancla), t0).group(1)
escribir(p, reemplazar(t0, ancla, ancla + s + ind + '<item name="colorTarjeta">?attr/colorSurfaceContainerHigh</item>'
                        + s + ind + '<item name="colorFilaAccion">?attr/colorSurfaceContainerHighest</item>'), t0)

# ---------- 6. estilos ----------
p = RES + '/values/styles.xml'
t0 = leer(p)
s = nl(t0)
t = reemplazar(t0, '<item name="android:background">?attr/colorSurface</item>' + s + '        <item name="titleTextAppearance">',
               '<item name="android:background">?attr/colorFondoPantalla</item>' + s + '        <item name="titleCentered">true</item>' + s + '        <item name="titleTextAppearance">')
t = reemplazar(t, '        <item name="backgroundTint">?attr/colorSurfaceContainer</item>' + s + '        <item name="itemActiveIndicatorStyle">',
               s.join(['        <item name="android:background">@drawable/bg_barra_inferior</item>',
                       '        <item name="elevation">3dp</item>',
                       '        <item name="itemIconTint">@color/selector_icono_barra</item>',
                       '        <item name="itemTextColor">@color/selector_texto_barra</item>',
                       '        <item name="itemPaddingTop">14dp</item>',
                       '        <item name="itemPaddingBottom">14dp</item>',
                       '        <item name="activeIndicatorLabelPadding">8dp</item>',
                       '        <item name="itemActiveIndicatorStyle">']))
t = reemplazar(t, '        <item name="android:color">?attr/colorSecondaryContainer</item>' + s + '    </style>',
               s.join(['        <item name="android:color">?attr/colorPrimary</item>',
                       '        <item name="android:width">48dp</item>',
                       '        <item name="android:height">48dp</item>',
                       '        <item name="shapeAppearance">@style/ShapeAppearance.Material3.Corner.Full</item>',
                       '    </style>']))
t = reemplazar(t, '        <item name="tabIndicatorColor">?attr/colorPrimary</item>',
               '        <item name="android:background">?attr/colorFondoPantalla</item>' + s + '        <item name="tabIndicatorColor">?attr/colorPrimary</item>')
t = reemplazar(t, '        <item name="cardBackgroundColor">?attr/colorSurfaceContainerLow</item>' + s + '        <item name="strokeWidth">0dp</item>' + s
               + '        <item name="cardElevation">1dp</item>' + s + '        <item name="cardCornerRadius">@dimen/card_corner_radius</item>',
               '        <item name="cardBackgroundColor">?attr/colorTarjeta</item>' + s + '        <item name="strokeWidth">0dp</item>' + s
               + '        <item name="cardElevation">1dp</item>' + s + '        <item name="cardCornerRadius">@dimen/card_corner_radius_grande</item>')
bloque = s.join([
    '    <style name="Widget.SonidoSonic.CardView.Tarjeta" parent="Widget.Material3.CardView.Filled">',
    '        <item name="cardBackgroundColor">?attr/colorTarjeta</item>',
    '        <item name="strokeWidth">0dp</item>',
    '        <item name="cardElevation">0dp</item>',
    '        <item name="cardCornerRadius">@dimen/card_corner_radius_grande</item>',
    '    </style>',
    '',
    '    <style name="Widget.SonidoSonic.Toolbar.Navegacion" parent="Widget.AppCompat.Toolbar.Button.Navigation">',
    '        <item name="android:background">@drawable/bg_boton_circular</item>',
    '    </style>'])
t = insertar_antes_cierre(t, '</resources>', ['', bloque])
escribir(p, t, t0)

# ---------- 7. strings ----------
p = RES + '/values/strings.xml'
t0 = leer(p)
assert 'name="dash_' not in t0
nuevas = [
    '    <!-- Dashboard estilo BBVA -->',
    '    <string name="dash_avisos_contador">%1$d de %2$d</string>',
    '    <string name="dash_aviso_anterior">Aviso anterior</string>',
    '    <string name="dash_aviso_siguiente">Aviso siguiente</string>',
    '    <string name="dash_aviso_proximo_evento">Próximo evento</string>',
    '    <string name="dash_aviso_proximo_detalle">%1$s · %2$s · %3$s</string>',
    '    <string name="dash_aviso_ver_pedido">Ver pedido</string>',
    '    <string name="dash_aviso_revision_etiqueta">Requiere tu atención</string>',
    '    <plurals name="dash_aviso_revision_titulo">',
    '        <item quantity="one">%d pedido por revisar</item>',
    '        <item quantity="other">%d pedidos por revisar</item>',
    '    </plurals>',
    '    <string name="dash_aviso_revision_detalle">Revísalos para confirmarlos o rechazarlos a tiempo.</string>',
    '    <string name="dash_aviso_ir_pedidos">Ir a pedidos</string>',
    '    <string name="dash_aviso_apartados_etiqueta">Apartados por vencer</string>',
    '    <plurals name="dash_aviso_apartados_titulo">',
    '        <item quantity="one">%d apartado sin anticipo</item>',
    '        <item quantity="other">%d apartados sin anticipo</item>',
    '    </plurals>',
    '    <string name="dash_aviso_apartados_detalle">El primero vence el %1$s a las %2$s.</string>',
    '    <string name="dash_aviso_al_dia_etiqueta">Todo al día</string>',
    '    <string name="dash_aviso_al_dia_titulo">No hay pendientes</string>',
    '    <string name="dash_aviso_al_dia_detalle">Aquí verás tus próximos eventos y los pedidos que necesiten atención.</string>',
    '    <string name="dash_ver_agenda">Ver agenda</string>',
    '    <string name="dash_ver_finanzas">Ver finanzas</string>',
    '    <string name="dash_ver_paquetes">Ver paquetes</string>',
    '    <string name="dash_eventos_semana_titulo">Eventos de esta semana</string>',
    '    <plurals name="dash_eventos_semana_total">',
    '        <item quantity="one">%d evento programado de lunes a domingo</item>',
    '        <item quantity="other">%d eventos programados de lunes a domingo</item>',
    '    </plurals>',
    '    <string name="dash_pendientes_titulo">Pendientes</string>',
    '    <string name="dash_ingresos_seccion">Ingresos netos</string>',
    '    <string name="dash_ultimos_6_meses">Últimos 6 meses</string>',
    '    <string name="dash_ingresos_periodo">Total del periodo: %1$s</string>',
    '    <string name="dash_paquetes_seccion">Paquetes más rentados</string>',
    '    <string name="dash_paquetes_subtitulo">Los 5 paquetes con más pedidos</string>',
    '    <string name="dash_paquetes_vacio">Todavía no hay pedidos en este periodo.</string>',
    '    <plurals name="dash_paquetes_rentas">',
    '        <item quantity="one">%d pedido</item>',
    '        <item quantity="other">%d pedidos</item>',
    '    </plurals>']
escribir(p, insertar_antes_cierre(t0, '</resources>', nuevas), t0)

# ---------- 8. activity_main: barra inferior flotante ----------
p = RES + '/layout/activity_main.xml'
t0 = leer(p)
s = nl(t0)
viejo = re.search(r'android:id="@\+id/bottomNavigationView"\s*android:layout_width="match_parent"\s*android:layout_height="wrap_content"', t0)
assert viejo
ind = re.search(r'(\r?\n)([ \t]*)android:layout_width="match_parent"', viejo.group(0)).group(2)
nuevo = s.join(['android:id="@+id/bottomNavigationView"',
                ind + 'android:layout_width="match_parent"',
                ind + 'android:layout_height="88dp"',
                ind + 'android:layout_marginStart="@dimen/spacing_medium"',
                ind + 'android:layout_marginTop="@dimen/spacing_small"',
                ind + 'android:layout_marginEnd="@dimen/spacing_medium"',
                ind + 'app:paddingBottomSystemWindowInsets="false"'])
escribir(p, t0.replace(viejo.group(0), nuevo, 1), t0)

# ---------- 9. MainActivity: margen inferior según la barra del sistema ----------
p = JAVA + '/MainActivity.java'
t0 = leer(p)
s = nl(t0)
viejo = 'findViewById(R.id.bottomNavigationView).setPadding(0, 0, 0, systemBars.bottom);'
ind = re.search(r'([ \t]*)' + re.escape(viejo), t0).group(1)
nuevo = s.join(['View barraInferior = findViewById(R.id.bottomNavigationView);',
                ind + 'android.view.ViewGroup.MarginLayoutParams margenesBarra = (android.view.ViewGroup.MarginLayoutParams) barraInferior.getLayoutParams();',
                ind + 'margenesBarra.bottomMargin = systemBars.bottom + getResources().getDimensionPixelSize(R.dimen.spacing_small);',
                ind + 'barraInferior.setLayoutParams(margenesBarra);'])
escribir(p, reemplazar(t0, viejo, nuevo), t0)

# ---------- 10. Fondos de pantalla y tarjetas especiales ----------
cambios_fondo = 0
for f in sorted(glob.glob(RES + '/layout/fragment_*.xml')):
    if f.endswith('fragment_dashboard.xml'):
        continue
    t0 = leer(f)
    m = re.search(r'<(?!\?)[\w.]+\b[^>]*>', t0)      # etiqueta raíz
    raiz = m.group(0)
    t = t0
    if 'android:background="?attr/colorSurface"' in raiz:
        t = t0[:m.start()] + raiz.replace('android:background="?attr/colorSurface"', 'android:background="?attr/colorFondoPantalla"') + t0[m.end():]
        cambios_fondo += 1
    t = t.replace('app:cardBackgroundColor="?attr/colorSurfaceContainerHigh"', 'app:cardBackgroundColor="?attr/colorTarjeta"')
    t = t.replace('app:cardBackgroundColor="?attr/colorSurfaceContainer"', 'app:cardBackgroundColor="?attr/colorTarjeta"')
    escribir(f, t, t0)

print('\n'.join(log))
print(len(log), 'archivos; fondos de pantalla cambiados:', cambios_fondo)
